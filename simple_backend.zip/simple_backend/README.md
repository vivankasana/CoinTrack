# Coin Track: simple backend

One file (`main.py`, about 90 lines), three jobs:

| Job | Method and URL | Send | Get back |
|---|---|---|---|
| Add an expense | `POST /expenses` | title, amount, category, date | the saved expense (with its `id`) |
| List all expenses | `GET /expenses` | nothing | a list, newest first |
| Delete an expense | `DELETE /expenses/{id}` | nothing | `{"deleted": id}`, or 404 if the id does not exist |

Example to send for POST:

```json
{"title": "Lunch", "amount": 120, "category": "Food", "date": "2026-10-06"}
```

Wrong data (negative amount, empty title, bad date) gets a 422 error and is not saved.

## Run

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload
```

Open http://127.0.0.1:8000/docs. Click a route, then "Try it out", to use it.

## Test

```bash
pytest -v
```

## How to read main.py

Read it top to bottom. It has four parts: the app, the database, the rules
(what a valid expense is), and the routes. Each route is a normal Python
function with one line above it that says which URL it belongs to.
