from fastapi.testclient import TestClient

import main


def new_client(tmp_path, monkeypatch):
    # Each test uses its own empty database file.
    monkeypatch.setenv("COINTRACK_DB", str(tmp_path / "test.db"))
    return TestClient(main.app)


GOOD = {"title": "Lunch", "amount": 120, "category": "Food", "date": "2026-10-06"}


def test_add_then_list(tmp_path, monkeypatch):
    client = new_client(tmp_path, monkeypatch)
    r = client.post("/expenses", json=GOOD)
    assert r.status_code == 201
    assert r.json()["id"] == 1
    listed = client.get("/expenses").json()
    assert len(listed) == 1 and listed[0]["title"] == "Lunch"


def test_list_is_empty_at_start(tmp_path, monkeypatch):
    client = new_client(tmp_path, monkeypatch)
    assert client.get("/expenses").json() == []


def test_bad_input_is_rejected(tmp_path, monkeypatch):
    client = new_client(tmp_path, monkeypatch)
    assert client.post("/expenses", json={**GOOD, "amount": -5}).status_code == 422
    assert client.post("/expenses", json={**GOOD, "title": ""}).status_code == 422
    assert client.post("/expenses", json={**GOOD, "date": "yesterday"}).status_code == 422
    assert client.get("/expenses").json() == []  # nothing was saved


def test_delete(tmp_path, monkeypatch):
    client = new_client(tmp_path, monkeypatch)
    client.post("/expenses", json=GOOD)
    assert client.delete("/expenses/1").status_code == 200
    assert client.get("/expenses").json() == []


def test_delete_missing_gives_404(tmp_path, monkeypatch):
    client = new_client(tmp_path, monkeypatch)
    assert client.delete("/expenses/999").status_code == 404
