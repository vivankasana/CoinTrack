"""Coin Track: simple backend.

Three jobs:
  1. Add an expense      POST   /expenses
  2. List all expenses   GET    /expenses
  3. Delete an expense   DELETE /expenses/{id}

Run it with:  uvicorn main:app --reload
Then open:    http://127.0.0.1:8000/docs
"""
import datetime
import os
import sqlite3

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# ---------------------------------------------------------------
# 1. The app
# ---------------------------------------------------------------
app = FastAPI(title="Coin Track")

# Lets a web page running on another port talk to this API.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------
# 2. The database (one file on your computer: coin_track.db)
# ---------------------------------------------------------------
def connect():
    """Open the database. We open a new connection for every request."""
    path = os.environ.get("COINTRACK_DB", "coin_track.db")
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row  # lets us write row["title"]
    # Create the table the first time. Does nothing if it already exists.
    conn.execute(
        """CREATE TABLE IF NOT EXISTS expenses (
               id       INTEGER PRIMARY KEY AUTOINCREMENT,
               title    TEXT NOT NULL,
               amount   REAL NOT NULL,
               category TEXT NOT NULL,
               date     TEXT NOT NULL
           )"""
    )
    return conn


# ---------------------------------------------------------------
# 3. The rules: what a valid expense looks like
# ---------------------------------------------------------------
class ExpenseIn(BaseModel):
    title: str = Field(min_length=1, max_length=100)  # not empty
    amount: float = Field(gt=0)                       # must be above 0
    category: str = Field(min_length=1, max_length=50)
    date: datetime.date                               # format YYYY-MM-DD


# ---------------------------------------------------------------
# 4. The routes
# ---------------------------------------------------------------
@app.post("/expenses", status_code=201)
def add_expense(expense: ExpenseIn):
    conn = connect()
    cursor = conn.execute(
        "INSERT INTO expenses (title, amount, category, date) VALUES (?, ?, ?, ?)",
        (expense.title, expense.amount, expense.category, expense.date.isoformat()),
    )
    conn.commit()
    new_id = cursor.lastrowid
    conn.close()
    return {"id": new_id, **expense.model_dump(mode="json")}


@app.get("/expenses")
def list_expenses():
    conn = connect()
    rows = conn.execute("SELECT * FROM expenses ORDER BY date DESC, id DESC").fetchall()
    conn.close()
    return [dict(row) for row in rows]


@app.delete("/expenses/{expense_id}")
def delete_expense(expense_id: int):
    conn = connect()
    cursor = conn.execute("DELETE FROM expenses WHERE id = ?", (expense_id,))
    conn.commit()
    conn.close()
    if cursor.rowcount == 0:  # nothing was deleted, so that id does not exist
        raise HTTPException(status_code=404, detail="Expense not found")
    return {"deleted": expense_id}
